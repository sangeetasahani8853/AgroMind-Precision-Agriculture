import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

export default function DiagnoseScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Crop Health Diagnosis</Text>
      <Text style={styles.text}>[Image upload & AI diagnosis functionality coming soon]</Text>
      <Button title="Back to Home" onPress={() => navigation.navigate('Home')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex:1, justifyContent:'center', alignItems:'center', padding: 20 },
  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 10 },
  text: { fontSize: 16, marginBottom: 20, textAlign: 'center' }
});