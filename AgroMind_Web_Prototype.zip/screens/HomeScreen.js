import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

export default function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Welcome to AgroMind</Text>
      <Button title="Diagnose Crop" onPress={() => navigation.navigate('Diagnose Crop')} />
      <Button title="Insights" onPress={() => navigation.navigate('Insights')} />
      <Button title="Chatbot" onPress={() => navigation.navigate('Chatbot')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex:1, justifyContent:'center', alignItems:'center', padding: 20 },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20 }
});